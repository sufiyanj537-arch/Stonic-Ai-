package com.stonic.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun StonicOrb(
    animated: Boolean,
    modifier: Modifier = Modifier,
    orbSize: Dp = 150.dp,
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val scale = if (animated) pulse else 1f

    Canvas(modifier = modifier.size(orbSize)) {
        val radius = (this.size.minDimension / 2f) * scale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF8B7CFF).copy(alpha = 0.95f),
                    Color(0xFF4DA3FF).copy(alpha = 0.55f),
                    Color.Transparent,
                ),
                center = center,
                radius = radius,
            ),
            radius = radius,
            center = center,
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.10f),
            radius = radius * 0.32f,
            center = center,
        )
    }
}
