package com.stonic.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF0A0A1A),
    secondary = Color(0xFF4DA3FF),
    onSecondary = Color(0xFF04101F),
    background = Color(0xFF05060F),
    onBackground = Color(0xFFE8E9F5),
    surface = Color(0xFF0B0E22),
    onSurface = Color(0xFFE8E9F5),
    surfaceVariant = Color(0xFF141836),
    onSurfaceVariant = Color(0xFFB4B8D6),
    outline = Color(0xFF3A3F66),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF1E6FD9),
    onSecondary = Color(0xFFFFFFFF),
    background = Color(0xFFF6F7FF),
    onBackground = Color(0xFF0B0E22),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B0E22),
    surfaceVariant = Color(0xFFE6E8FA),
    onSurfaceVariant = Color(0xFF454A70),
    outline = Color(0xFF8A8FB5),
)

@Composable
fun StonicTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
