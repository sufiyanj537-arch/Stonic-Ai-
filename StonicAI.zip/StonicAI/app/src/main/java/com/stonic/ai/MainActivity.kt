package com.stonic.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.stonic.ai.data.SettingsStore
import com.stonic.ai.ui.StonicApp
import com.stonic.ai.ui.theme.StonicTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val settings = SettingsStore(applicationContext)
        setContent {
            StonicTheme(darkTheme = settings.darkTheme) {
                StonicApp(settings)
            }
        }
    }
}
