package com.stonic.ai.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Stage 1: tiny local settings (theme + animations).
 * Never store API keys here. API keys get secure storage in Stage 2.
 */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("stonic_settings", Context.MODE_PRIVATE)

    var darkTheme by mutableStateOf(prefs.getBoolean(KEY_DARK, true))
        private set

    var animationsEnabled by mutableStateOf(prefs.getBoolean(KEY_ANIM, true))
        private set

    fun updateDarkTheme(value: Boolean) {
        darkTheme = value
        prefs.edit().putBoolean(KEY_DARK, value).apply()
    }

    fun updateAnimations(value: Boolean) {
        animationsEnabled = value
        prefs.edit().putBoolean(KEY_ANIM, value).apply()
    }

    private companion object {
        const val KEY_DARK = "dark_theme"
        const val KEY_ANIM = "animations_enabled"
    }
}
