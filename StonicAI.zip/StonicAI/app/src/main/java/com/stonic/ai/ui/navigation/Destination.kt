package com.stonic.ai.ui.navigation

enum class Destination(
    val route: String,
    val title: String,
    val emoji: String,
    val availableIn: String,
    val description: String,
) {
    Home("home", "Home", "🏠", "Stage 1", "Main screen."),
    Chat("chat", "Chat", "💬", "Stage 2", "Text chat with Stonic using the Gemini API, with chat history."),
    Voice("voice", "Voice", "🎙️", "Stage 3", "Speech-to-text and text-to-speech voice conversations."),
    Phone("phone", "Phone Control", "📱", "Stage 4-5", "Open apps, YouTube search, and user-authorized accessibility actions."),
    Tools("tools", "AI Tools", "🧰", "Stage 6", "Find, compare and learn AI tools; prompt helper."),
    Coding("coding", "Coding Lab", "👩‍💻", "Stage 6", "Generate, explain and debug code. Copy and save snippets."),
    Memory("memory", "Memory", "🧠", "Stage 7", "See, edit and delete what Stonic remembers."),
    Settings("settings", "Settings", "⚙️", "Stage 1", "App settings.");

    companion object {
        val all: List<Destination> = entries
    }
}
