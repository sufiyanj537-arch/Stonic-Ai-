package com.stonic.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.stonic.ai.BuildConfig
import com.stonic.ai.data.SettingsStore

@Composable
fun SettingsScreen(settings: SettingsStore) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SettingsCard("Appearance") {
                SwitchRow("Dark theme", "Turn off for light theme", settings.darkTheme) { settings.updateDarkTheme(it) }
                SwitchRow("Animations", "Orb pulse animation", settings.animationsEnabled) { settings.updateAnimations(it) }
            }
        }
        item {
            SettingsCard("AI (Gemini)") {
                FutureRow("Gemini API key, model, connection test", "Stage 2")
            }
        }
        item {
            SettingsCard("Voice") {
                FutureRow("Speech language, voice, speed", "Stage 3")
            }
        }
        item {
            SettingsCard("Personality") {
                FutureRow("Companion / professional mode, custom instructions", "Stage 2")
            }
        }
        item {
            SettingsCard("Automation") {
                FutureRow("Accessibility status, permissions, safety controls", "Stage 5")
            }
        }
        item {
            SettingsCard("Privacy") {
                FutureRow("Conversation history, memory, clear local data", "Stage 2 / 7")
            }
        }
        item {
            SettingsCard("About") {
                ListItem(
                    headlineContent = { Text("Stonic AI") },
                    supportingContent = { Text("Version ${BuildConfig.VERSION_NAME}") },
                    colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                )
                ListItem(
                    headlineContent = { Text("Privacy") },
                    supportingContent = { Text("Stage 1 collects no data and uses no internet or permissions.") },
                    colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                )
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(vertical = 8.dp)) {
            Text(
                title,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
            )
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) },
        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
    )
}

@Composable
private fun FutureRow(title: String, stage: String) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text("Coming in $stage") },
        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
    )
}
